from app import t_app

t_app.run(host='0.0.0.0', port=8080)
