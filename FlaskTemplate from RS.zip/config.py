WTF_CSRF_ENABLED = True
SECRET_KEY = 'somesupersecretkey'