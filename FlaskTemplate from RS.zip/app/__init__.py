from flask import Flask

# This will create a flask application object called t_app
t_app = Flask(__name__)
t_app.config.from_object('config')
from app import views

from .util import assets