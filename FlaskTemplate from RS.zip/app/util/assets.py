from flask_assets import Bundle, Environment

from app import t_app

bundles ={
    'home_css':Bundle('css/style.css'),
    'responsive_css': Bundle('css/responsive.css'),
    'home_image':Bundle('image/home.png')
}

assets = Environment(t_app)

assets.register(bundles)