from flask import render_template
from app import t_app
from app.forms import CountrySearch
from app.search_op import search_google

@t_app.route('/')
@t_app.route('/index')
def index():
    return render_template('index.html')

@t_app.route('/search', methods=['GET','POST'])
def search():
    info = None
    fm = CountrySearch()
    if fm.validate_on_submit():
        country = fm.country_name.data
        info = search_google(country)
    return render_template('search.html',title = 'Search a country',
                           form=fm, info = info)

@t_app.route('/responsive_menu')
def responsive_menu():
    return render_template('responsive_menu.html')