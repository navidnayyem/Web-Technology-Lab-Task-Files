function validation(arg){
  // arg is used to pass value
  vargName = arg.name.value;
  //Get the value of name (selecter) and put in gName(variable)
  vargPhone = arg.phone.value;
  vargEmail = arg.email.value;
  vargComm = arg.comm.value;

  varePat = /^[a-z-.0-9]+@[a-z0-9]+\.[a-z.]{2,5}$/;
  varnamePatDt = /\./;
  varnamePatDgt = /\d/;
  var err = "";
  varerrNum = 0;

  if (gName == "" || gName.lenght <3 || namePatDt.test(gName)||namePatDgt.test(gName)){
    errNum++;
    err+=errNum + ".Invalid name .\n";
  }
  if (gPhone == "" || gPhone.lenght<8 || isNaN(gPhone)){
    errNum++;
    err+=errNum + ".Invalid Phone num .\n";
  }
  if(gEmail == ""){
    errNum++;
    err+=errNum + ". Enter Email.\n";
  }
  else{
    if(!ePat.test(gEmail)){
      e
    }
  }
}