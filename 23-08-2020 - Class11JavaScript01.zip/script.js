function myfunction(){

  //var value1 = 5.4;
  //var value2 = 5;
  //var sum = value1+value2;  

  var sum = 0;
  for(var i=0; i<20;i++){
    sum = sum+i;
    document.getElementById("test1").innerHTML = i;
    console.log(i);
  }
  var st = "5";
  var s1="Hello World";
  var s2="";
  for(var i=0; i<s1.length;i++){
    s2=s2+s1.charAt(i)+s1.charAt(i);
  }
  console.log(s2);

  console.log("Hello World console");
  //document.getElementById("test1").innerHTML = sum;
  //document.write("Hello World!");
  /*alert("Hello World");*/
}

function sum(){
  num1 = parseInt(document.getElementById("num1").value);
  num2 = parseInt( document.getElementById("num2").value);
  document.getElementById("results").innerHTML = num1+num2;
}

function div(){
  num1 = parseInt(document.getElementById("num1").value);
  num2 = parseInt( document.getElementById("num2").value);
  document.getElementById("results").innerHTML = (num1/num2).toPrecision(3);
}

function mul(){
  num1 = parseInt(document.getElementById("num1").value);
  num2 = parseInt( document.getElementById("num2").value);
  document.getElementById("results").innerHTML = num1*num2;
}

function sub(){
  num1 = parseInt(document.getElementById("num1").value);
  num2 = parseInt( document.getElementById("num2").value);
  document.getElementById("results").innerHTML = num1-num2;
}

function Check(){
  num1 = parseInt(document.getElementById("num1").value);
  num2 = parseInt( document.getElementById("num2").value);

  if(num1>num2){
    document.getElementById("condition").innerHTML = num1+" is greater than "+num2;
  }else if (num1 == num2){
    document.getElementById("condition").innerHTML = num1+" is equal to "+ num2;
  }else{
      document.getElementById("condition").innerHTML = num2+" is greater than "+ num1;
  }
}